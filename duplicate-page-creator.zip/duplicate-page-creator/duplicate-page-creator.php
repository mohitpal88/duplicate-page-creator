<?php
/*
Plugin Name: Duplicate Page/Post Creator
Description: Easily duplicate any post, page, or custom post type item as a draft.
Version: 2.0
Author: Mohit Pal
Author URI: https://themohitpal.com/
Github: https://github.com/mohitpal88
License: GPL2
*/

if (!defined('ABSPATH')) exit;

// Add 'Duplicate' action link to post/page/custom post list
function dpc_add_duplicate_link($actions, $post) {
    if (current_user_can('edit_posts')) {
        $duplicate_url = wp_nonce_url(
            admin_url('admin.php?action=dpc_duplicate_post&post=' . $post->ID),
            basename(__FILE__),
            'duplicate_nonce'
        );
        $actions['duplicate'] = '<a href="' . esc_url($duplicate_url) . '" title="Duplicate this item" rel="permalink">Duplicate</a>';
    }
    return $actions;
}

// Apply the link to all public post types
function dpc_add_to_post_types() {
    $post_types = get_post_types(['public' => true], 'names');
    foreach ($post_types as $post_type) {
        add_filter("{$post_type}_row_actions", 'dpc_add_duplicate_link', 10, 2);
    }
}
add_action('admin_init', 'dpc_add_to_post_types');

// Handle duplication logic
function dpc_duplicate_post() {
    if (!isset($_GET['post']) || !isset($_GET['duplicate_nonce']) || !wp_verify_nonce($_GET['duplicate_nonce'], basename(__FILE__))) {
        wp_die('Security check failed.');
    }

    $post_id = absint($_GET['post']);
    $post = get_post($post_id);

    if (!$post) {
        wp_die('Original post not found.');
    }

    $new_post_args = [
        'post_title'    => $post->post_title . ' (Copy)',
        'post_content'  => $post->post_content,
        'post_status'   => 'draft',
        'post_type'     => $post->post_type,
        'post_author'   => get_current_user_id(),
        'post_excerpt'  => $post->post_excerpt,
        'post_parent'   => $post->post_parent,
        'post_password' => $post->post_password,
        'menu_order'    => $post->menu_order,
        'to_ping'       => $post->to_ping,
        'pinged'        => $post->pinged,
        'post_content_filtered' => $post->post_content_filtered,
    ];

    $new_post_id = wp_insert_post($new_post_args);

    // Copy taxonomy terms
    $taxonomies = get_object_taxonomies($post->post_type);
    foreach ($taxonomies as $taxonomy) {
        $terms = wp_get_object_terms($post_id, $taxonomy, ['fields' => 'slugs']);
        wp_set_object_terms($new_post_id, $terms, $taxonomy, false);
    }

    // Copy custom fields
    $meta = get_post_meta($post_id);
    foreach ($meta as $key => $values) {
        foreach ($values as $value) {
            update_post_meta($new_post_id, $key, maybe_unserialize($value));
        }
    }

    // Redirect to edit screen
    wp_redirect(admin_url('post.php?action=edit&post=' . $new_post_id));
    exit;
}
add_action('admin_action_dpc_duplicate_post', 'dpc_duplicate_post');
